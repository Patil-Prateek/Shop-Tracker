# Firebase Security Rules

Go to Firebase Console → Firestore Database → Rules and paste this:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /shops/{shopCode} {
      allow read, write: if true;

      match /products/{productId} {
        allow read, write: if true;
      }

      match /sales/{saleId} {
        allow read, write: if true;
      }
    }
  }
}
```

NOTE: These are open rules for development/testing.
When you're ready for production, tighten them with proper auth.
