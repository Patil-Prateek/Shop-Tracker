# ShopSync - Sales Tracker

A real-time sales tracking PWA for small shops.

## Setup & Run

### 1. Install dependencies
```
npm install
```

### 2. Start the app
```
npm start
```
Opens at http://localhost:3000

### 3. Set Firebase Rules
Go to Firebase Console → Firestore → Rules
Paste the rules from FIREBASE_RULES.md

### 4. Install on Phone (PWA)

**Android:**
- Open Chrome → go to your app URL
- Tap the 3-dot menu → "Add to Home Screen"

**iOS:**
- Open Safari → go to your app URL
- Tap Share button → "Add to Home Screen"

## How it works

1. **Manager** creates a shop → gets a 6-character code (e.g. ABC123)
2. **Manager** adds products with prices
3. **Employees** open the app → enter shop code + their name
4. Employees log sales from their devices
5. Manager sees live leaderboard, totals, and all sales

## Deploy (Free hosting)

```
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy
```

Your app will be live at: https://shop-tracker-b5fd0.web.app
