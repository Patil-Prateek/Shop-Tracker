import React, { useState, useEffect } from "react";
import WelcomePage from "./pages/WelcomePage";
import EmployeeDashboard from "./pages/EmployeeDashboard";
import ManagerDashboard from "./pages/ManagerDashboard";
import "./index.css";

const SESSION_KEY = "shopsync_session";

function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(SESSION_KEY);
      if (saved) setSession(JSON.parse(saved));
    } catch (e) {}
    setLoading(false);
  }, []);

  const handleJoin = (sessionData) => {
    localStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
    setSession(sessionData);
  };

  const handleLogout = () => {
    localStorage.removeItem(SESSION_KEY);
    setSession(null);
  };

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#0F172A" }}>
        <div style={{ width: "32px", height: "32px", border: "3px solid #334155", borderTopColor: "#10B981", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
      </div>
    );
  }

  if (!session) return <WelcomePage onJoin={handleJoin} />;
  if (session.role === "manager") return <ManagerDashboard session={session} onLogout={handleLogout} />;
  return <EmployeeDashboard session={session} onLogout={handleLogout} />;
}

export default App;
