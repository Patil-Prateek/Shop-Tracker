import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyBuzgoEQ8i-Jvw4sxSPBsyi4vV8_clXPJ0",
  authDomain: "shop-tracker-b5fd0.firebaseapp.com",
  databaseURL: "https://shop-tracker-b5fd0-default-rtdb.firebaseio.com",
  projectId: "shop-tracker-b5fd0",
  storageBucket: "shop-tracker-b5fd0.firebasestorage.app",
  messagingSenderId: "289769273606",
  appId: "1:289769273606:web:50985d0df302ad058c4687",
  measurementId: "G-GTP0D0VG8L"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const rtdb = getDatabase(app);
export default app;
