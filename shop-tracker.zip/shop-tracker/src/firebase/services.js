import {
  collection,
  doc,
  setDoc,
  getDoc,
  addDoc,
  onSnapshot,
  query,
  where,
  serverTimestamp,
  updateDoc,
  orderBy,
} from "firebase/firestore";
import { db } from "./config";

// ─── Shop ────────────────────────────────────────────────────────────────────

export const createShop = async (shopName, ownerName) => {
  const code = Math.random().toString(36).substring(2, 8).toUpperCase();
  const shopRef = doc(db, "shops", code);
  await setDoc(shopRef, {
    name: shopName,
    owner: ownerName,
    code,
    createdAt: serverTimestamp(),
  });
  return code;
};

export const getShop = async (code) => {
  const shopRef = doc(db, "shops", code.toUpperCase());
  const snap = await getDoc(shopRef);
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() };
};

// ─── Products ────────────────────────────────────────────────────────────────

export const addProduct = async (shopCode, name, price) => {
  const ref = collection(db, "shops", shopCode, "products");
  const docRef = await addDoc(ref, {
    name,
    price: parseFloat(price),
    createdAt: serverTimestamp(),
  });
  return docRef.id;
};

export const listenToProducts = (shopCode, callback) => {
  const ref = collection(db, "shops", shopCode, "products");
  return onSnapshot(ref, (snap) => {
    const products = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    callback(products);
  });
};

// ─── Sales ───────────────────────────────────────────────────────────────────

export const logSale = async (shopCode, employeeName, productId, productName, quantity, price) => {
  const ref = collection(db, "shops", shopCode, "sales");
  await addDoc(ref, {
    employeeName,
    productId,
    productName,
    quantity: parseInt(quantity),
    price: parseFloat(price),
    total: parseFloat(price) * parseInt(quantity),
    createdAt: serverTimestamp(),
  });
};

export const listenToSales = (shopCode, callback) => {
  const ref = query(
    collection(db, "shops", shopCode, "sales"),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(ref, (snap) => {
    const sales = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    callback(sales);
  });
};

export const listenToTodaySales = (shopCode, callback) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const ref = query(
    collection(db, "shops", shopCode, "sales"),
    where("createdAt", ">=", today),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(ref, (snap) => {
    const sales = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    callback(sales);
  });
};
