import React, { useState, useEffect } from "react";
import { logSale, listenToProducts, listenToSales, addProduct } from "../firebase/services";

const EmployeeDashboard = ({ session, onLogout }) => {
  const [products, setProducts] = useState([]);
  const [sales, setSales] = useState([]);
  const [tab, setTab] = useState("sell"); // 'sell' | 'history'
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [quantity, setQuantity] = useState("1");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProductName, setNewProductName] = useState("");
  const [newProductPrice, setNewProductPrice] = useState("");

  useEffect(() => {
    const unsub1 = listenToProducts(session.shopCode, setProducts);
    const unsub2 = listenToSales(session.shopCode, setSales);
    return () => { unsub1(); unsub2(); };
  }, [session.shopCode]);

  const mySales = sales.filter(s => s.employeeName === session.name);
  const myTotal = mySales.reduce((sum, s) => sum + (s.total || 0), 0);
  const myTodaySales = mySales.filter(s => {
    if (!s.createdAt) return false;
    const saleDate = s.createdAt.toDate ? s.createdAt.toDate() : new Date(s.createdAt);
    const today = new Date();
    return saleDate.toDateString() === today.toDateString();
  });
  const myTodayTotal = myTodaySales.reduce((sum, s) => sum + (s.total || 0), 0);

  const handleSell = async () => {
    if (!selectedProduct || !quantity) return;
    setLoading(true);
    await logSale(
      session.shopCode,
      session.name,
      selectedProduct.id,
      selectedProduct.name,
      quantity,
      selectedProduct.price
    );
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
    setSelectedProduct(null);
    setQuantity("1");
    setLoading(false);
  };

  const handleAddProduct = async () => {
    if (!newProductName.trim() || !newProductPrice) return;
    await addProduct(session.shopCode, newProductName.trim(), newProductPrice);
    setNewProductName("");
    setNewProductPrice("");
    setShowAddProduct(false);
  };

  const formatTime = (ts) => {
    if (!ts) return "";
    const d = ts.toDate ? ts.toDate() : new Date(ts);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div style={styles.page}>
      {/* Header */}
      <div style={styles.header}>
        <div>
          <p style={styles.greeting}>Hey, {session.name} 👋</p>
          <p style={styles.shopName}>{session.shopName || session.shopCode}</p>
        </div>
        <div style={styles.headerRight}>
          <div style={styles.codeBadge}>{session.shopCode}</div>
          <button style={styles.logoutBtn} onClick={onLogout}>✕</button>
        </div>
      </div>

      {/* Today's stat */}
      <div style={styles.statCard} className="fade-up">
        <p style={styles.statLabel}>Your sales today</p>
        <p style={styles.statAmount}>₹{myTodayTotal.toFixed(2)}</p>
        <p style={styles.statCount}>{myTodaySales.length} transaction{myTodaySales.length !== 1 ? "s" : ""}</p>
      </div>

      {/* Tabs */}
      <div style={styles.tabs}>
        <button style={{ ...styles.tab, ...(tab === "sell" ? styles.tabActive : {}) }} onClick={() => setTab("sell")}>
          Log Sale
        </button>
        <button style={{ ...styles.tab, ...(tab === "history" ? styles.tabActive : {}) }} onClick={() => setTab("history")}>
          My History
        </button>
      </div>

      {/* Sell Tab */}
      {tab === "sell" && (
        <div style={styles.content} className="fade-up">
          {products.length === 0 ? (
            <div style={styles.emptyState}>
              <p style={styles.emptyIcon}>📦</p>
              <p style={styles.emptyText}>No products yet.</p>
              <p style={styles.emptySub}>Add a product to start logging sales.</p>
            </div>
          ) : (
            <>
              <p style={styles.sectionLabel}>Select product</p>
              <div style={styles.productGrid}>
                {products.map(p => (
                  <button
                    key={p.id}
                    style={{
                      ...styles.productCard,
                      ...(selectedProduct?.id === p.id ? styles.productCardSelected : {}),
                    }}
                    onClick={() => setSelectedProduct(p)}
                  >
                    <p style={styles.productName}>{p.name}</p>
                    <p style={styles.productPrice}>₹{p.price}</p>
                  </button>
                ))}
              </div>
            </>
          )}

          {selectedProduct && (
            <div style={styles.sellForm} className="fade-up">
              <p style={styles.sectionLabel}>Quantity</p>
              <div style={styles.qtyRow}>
                <button style={styles.qtyBtn} onClick={() => setQuantity(q => String(Math.max(1, parseInt(q) - 1)))}>−</button>
                <input
                  style={styles.qtyInput}
                  type="number"
                  value={quantity}
                  min="1"
                  onChange={e => setQuantity(e.target.value)}
                />
                <button style={styles.qtyBtn} onClick={() => setQuantity(q => String(parseInt(q) + 1))}>+</button>
              </div>
              <div style={styles.totalRow}>
                <span style={styles.totalLabel}>Total</span>
                <span style={styles.totalAmount}>₹{(selectedProduct.price * parseInt(quantity || 1)).toFixed(2)}</span>
              </div>
              <button
                style={{ ...styles.sellBtn, ...(success ? styles.sellBtnSuccess : {}) }}
                onClick={handleSell}
                disabled={loading}
              >
                {success ? "✓ Sale Logged!" : loading ? "Logging..." : "Log Sale"}
              </button>
            </div>
          )}

          {/* Add product shortcut */}
          {!showAddProduct ? (
            <button style={styles.addProductBtn} onClick={() => setShowAddProduct(true)}>
              + Add new product
            </button>
          ) : (
            <div style={styles.addProductForm} className="fade-up">
              <p style={styles.sectionLabel}>New product</p>
              <input style={styles.input} placeholder="Product name" value={newProductName} onChange={e => setNewProductName(e.target.value)} />
              <input style={styles.input} placeholder="Price (₹)" type="number" value={newProductPrice} onChange={e => setNewProductPrice(e.target.value)} />
              <div style={{ display: "flex", gap: "8px" }}>
                <button style={styles.btnPrimary} onClick={handleAddProduct}>Add</button>
                <button style={styles.btnGhost} onClick={() => setShowAddProduct(false)}>Cancel</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* History Tab */}
      {tab === "history" && (
        <div style={styles.content} className="fade-up">
          <div style={styles.totalBanner}>
            <span>All-time total</span>
            <span style={{ fontWeight: 700, color: "#10B981" }}>₹{myTotal.toFixed(2)}</span>
          </div>
          {mySales.length === 0 ? (
            <div style={styles.emptyState}>
              <p style={styles.emptyIcon}>📋</p>
              <p style={styles.emptyText}>No sales yet.</p>
              <p style={styles.emptySub}>Start logging sales from the Sell tab.</p>
            </div>
          ) : (
            <div style={styles.salesList}>
              {mySales.map(s => (
                <div key={s.id} style={styles.saleRow}>
                  <div>
                    <p style={styles.saleName}>{s.productName}</p>
                    <p style={styles.saleMeta}>Qty {s.quantity} · {formatTime(s.createdAt)}</p>
                  </div>
                  <p style={styles.saleTotal}>₹{s.total?.toFixed(2)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const styles = {
  page: { minHeight: "100vh", background: "#0F172A", paddingBottom: "32px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 20px 0" },
  greeting: { fontSize: "20px", fontWeight: 800, color: "#F8FAFC" },
  shopName: { fontSize: "13px", color: "#64748B", marginTop: "2px" },
  headerRight: { display: "flex", alignItems: "center", gap: "8px" },
  codeBadge: { background: "rgba(16,185,129,0.15)", color: "#10B981", padding: "4px 10px", borderRadius: "20px", fontSize: "12px", fontWeight: 700, letterSpacing: "0.1em" },
  logoutBtn: { background: "rgba(255,255,255,0.06)", color: "#94A3B8", width: "32px", height: "32px", borderRadius: "8px", fontSize: "12px" },
  statCard: { margin: "20px", background: "linear-gradient(135deg, #10B981 0%, #059669 100%)", borderRadius: "20px", padding: "24px", position: "relative", overflow: "hidden" },
  statLabel: { fontSize: "13px", color: "rgba(255,255,255,0.75)", fontWeight: 500 },
  statAmount: { fontSize: "42px", fontWeight: 900, color: "#fff", letterSpacing: "-2px", marginTop: "4px", lineHeight: 1 },
  statCount: { fontSize: "13px", color: "rgba(255,255,255,0.65)", marginTop: "6px" },
  tabs: { display: "flex", margin: "0 20px", background: "rgba(255,255,255,0.05)", borderRadius: "12px", padding: "4px" },
  tab: { flex: 1, padding: "10px", borderRadius: "10px", fontSize: "14px", fontWeight: 600, background: "transparent", color: "#64748B" },
  tabActive: { background: "#1E293B", color: "#F8FAFC", boxShadow: "0 2px 8px rgba(0,0,0,0.2)" },
  content: { padding: "16px 20px" },
  sectionLabel: { fontSize: "12px", fontWeight: 700, color: "#64748B", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "10px" },
  productGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "16px" },
  productCard: { background: "#1E293B", border: "2px solid transparent", borderRadius: "14px", padding: "16px", textAlign: "left" },
  productCardSelected: { border: "2px solid #10B981", background: "rgba(16,185,129,0.08)" },
  productName: { fontSize: "14px", fontWeight: 600, color: "#F8FAFC" },
  productPrice: { fontSize: "18px", fontWeight: 800, color: "#10B981", marginTop: "4px" },
  sellForm: { background: "#1E293B", borderRadius: "16px", padding: "16px", marginBottom: "12px" },
  qtyRow: { display: "flex", alignItems: "center", gap: "12px", marginBottom: "16px" },
  qtyBtn: { width: "40px", height: "40px", background: "#334155", borderRadius: "10px", color: "#F8FAFC", fontSize: "20px", fontWeight: 700 },
  qtyInput: { flex: 1, background: "#0F172A", border: "1px solid #334155", borderRadius: "10px", color: "#F8FAFC", fontSize: "20px", fontWeight: 700, textAlign: "center", padding: "8px" },
  totalRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" },
  totalLabel: { fontSize: "14px", color: "#64748B", fontWeight: 600 },
  totalAmount: { fontSize: "24px", fontWeight: 900, color: "#F8FAFC" },
  sellBtn: { width: "100%", padding: "16px", background: "#10B981", color: "#fff", borderRadius: "12px", fontSize: "16px", fontWeight: 700 },
  sellBtnSuccess: { background: "#059669" },
  addProductBtn: { width: "100%", padding: "14px", background: "transparent", border: "1.5px dashed #334155", borderRadius: "12px", color: "#64748B", fontSize: "14px", fontWeight: 600, marginTop: "4px" },
  addProductForm: { background: "#1E293B", borderRadius: "16px", padding: "16px", marginTop: "8px", display: "flex", flexDirection: "column", gap: "10px" },
  input: { width: "100%", padding: "12px 14px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "10px", color: "#F8FAFC", fontSize: "14px" },
  btnPrimary: { flex: 1, padding: "12px", background: "#10B981", color: "#fff", borderRadius: "10px", fontSize: "14px", fontWeight: 700 },
  btnGhost: { flex: 1, padding: "12px", background: "transparent", color: "#64748B", borderRadius: "10px", fontSize: "14px" },
  totalBanner: { display: "flex", justifyContent: "space-between", background: "#1E293B", borderRadius: "12px", padding: "14px 16px", marginBottom: "12px", fontSize: "14px", color: "#94A3B8" },
  salesList: { display: "flex", flexDirection: "column", gap: "8px" },
  saleRow: { display: "flex", justifyContent: "space-between", alignItems: "center", background: "#1E293B", borderRadius: "12px", padding: "14px 16px" },
  saleName: { fontSize: "14px", fontWeight: 600, color: "#F8FAFC" },
  saleMeta: { fontSize: "12px", color: "#64748B", marginTop: "2px" },
  saleTotal: { fontSize: "16px", fontWeight: 800, color: "#10B981" },
  emptyState: { textAlign: "center", padding: "48px 20px" },
  emptyIcon: { fontSize: "40px", marginBottom: "12px" },
  emptyText: { fontSize: "16px", fontWeight: 700, color: "#F8FAFC", marginBottom: "6px" },
  emptySub: { fontSize: "13px", color: "#64748B" },
};

export default EmployeeDashboard;
