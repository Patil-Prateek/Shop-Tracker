import React, { useState, useEffect } from "react";
import { listenToSales, listenToProducts, addProduct } from "../firebase/services";

const ManagerDashboard = ({ session, onLogout }) => {
  const [sales, setSales] = useState([]);
  const [products, setProducts] = useState([]);
  const [tab, setTab] = useState("overview"); // overview | employees | products | all-sales
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    const unsub1 = listenToSales(session.shopCode, setSales);
    const unsub2 = listenToProducts(session.shopCode, setProducts);
    return () => { unsub1(); unsub2(); };
  }, [session.shopCode]);

  const today = new Date();
  const todaySales = sales.filter(s => {
    if (!s.createdAt) return false;
    const d = s.createdAt.toDate ? s.createdAt.toDate() : new Date(s.createdAt);
    return d.toDateString() === today.toDateString();
  });

  const totalToday = todaySales.reduce((sum, s) => sum + (s.total || 0), 0);
  const totalAll = sales.reduce((sum, s) => sum + (s.total || 0), 0);

  // Group by employee
  const employeeStats = sales.reduce((acc, s) => {
    if (!acc[s.employeeName]) acc[s.employeeName] = { name: s.employeeName, total: 0, count: 0, todayTotal: 0, todayCount: 0 };
    acc[s.employeeName].total += s.total || 0;
    acc[s.employeeName].count += 1;
    const d = s.createdAt?.toDate ? s.createdAt.toDate() : new Date(s.createdAt);
    if (d.toDateString() === today.toDateString()) {
      acc[s.employeeName].todayTotal += s.total || 0;
      acc[s.employeeName].todayCount += 1;
    }
    return acc;
  }, {});
  const employees = Object.values(employeeStats).sort((a, b) => b.todayTotal - a.todayTotal);

  // Product stats
  const productStats = sales.reduce((acc, s) => {
    if (!acc[s.productName]) acc[s.productName] = { name: s.productName, qty: 0, revenue: 0 };
    acc[s.productName].qty += s.quantity || 0;
    acc[s.productName].revenue += s.total || 0;
    return acc;
  }, {});
  const topProducts = Object.values(productStats).sort((a, b) => b.revenue - a.revenue);

  const handleAddProduct = async () => {
    if (!newName.trim() || !newPrice) return;
    setAdding(true);
    await addProduct(session.shopCode, newName.trim(), newPrice);
    setNewName(""); setNewPrice("");
    setAdding(false);
  };

  const formatTime = (ts) => {
    if (!ts) return "";
    const d = ts.toDate ? ts.toDate() : new Date(ts);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const avatarColor = (name) => {
    const colors = ["#10B981", "#F59E0B", "#6366F1", "#EC4899", "#14B8A6"];
    return colors[name.charCodeAt(0) % colors.length];
  };

  return (
    <div style={styles.page}>
      {/* Header */}
      <div style={styles.header}>
        <div>
          <p style={styles.shopName}>{session.shopName || "Manager View"}</p>
          <p style={styles.sub}>Manager · {session.name}</p>
        </div>
        <div style={styles.headerRight}>
          <div style={styles.codeBadge}>{session.shopCode}</div>
          <button style={styles.logoutBtn} onClick={onLogout}>✕</button>
        </div>
      </div>

      {/* Share code banner */}
      <div style={styles.shareBanner}>
        <span style={styles.shareIcon}>🔗</span>
        <div>
          <p style={styles.shareTitle}>Share this code with employees</p>
          <p style={styles.shareCode}>{session.shopCode}</p>
        </div>
      </div>

      {/* Tabs */}
      <div style={styles.tabs}>
        {["overview", "employees", "products", "sales"].map(t => (
          <button key={t} style={{ ...styles.tab, ...(tab === t ? styles.tabActive : {}) }} onClick={() => setTab(t)}>
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === "overview" && (
        <div style={styles.content} className="fade-up">
          <div style={styles.statsGrid}>
            <div style={styles.bigStatCard}>
              <p style={styles.bigStatLabel}>Today's Revenue</p>
              <p style={styles.bigStatValue}>₹{totalToday.toFixed(2)}</p>
              <p style={styles.bigStatSub}>{todaySales.length} sales</p>
            </div>
            <div style={styles.smallStatsCol}>
              <div style={styles.smallStatCard}>
                <p style={styles.smallStatLabel}>All-time</p>
                <p style={styles.smallStatValue}>₹{totalAll.toFixed(2)}</p>
              </div>
              <div style={styles.smallStatCard}>
                <p style={styles.smallStatLabel}>Active staff</p>
                <p style={styles.smallStatValue}>{employees.length}</p>
              </div>
            </div>
          </div>

          <p style={styles.sectionLabel}>Today's leaderboard</p>
          {employees.length === 0 ? (
            <p style={styles.emptyMsg}>No sales logged yet today.</p>
          ) : (
            <div style={styles.leaderboard}>
              {employees.map((e, i) => (
                <div key={e.name} style={styles.leaderRow}>
                  <div style={styles.leaderLeft}>
                    <div style={{ ...styles.avatar, background: avatarColor(e.name) }}>
                      {e.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p style={styles.leaderName}>{e.name}</p>
                      <p style={styles.leaderMeta}>{e.todayCount} sales today</p>
                    </div>
                  </div>
                  <div style={styles.leaderRight}>
                    <p style={styles.leaderTotal}>₹{e.todayTotal.toFixed(2)}</p>
                    {i === 0 && <span style={styles.crown}>👑</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Employees */}
      {tab === "employees" && (
        <div style={styles.content} className="fade-up">
          {employees.length === 0 ? (
            <div style={styles.emptyState}>
              <p style={styles.emptyIcon}>👥</p>
              <p style={styles.emptyText}>No employees yet.</p>
              <p style={styles.emptySub}>Share code <strong style={{ color: "#10B981" }}>{session.shopCode}</strong> for them to join.</p>
            </div>
          ) : (
            employees.map(e => (
              <div key={e.name} style={styles.employeeCard}>
                <div style={{ ...styles.avatar, background: avatarColor(e.name), width: "48px", height: "48px", fontSize: "20px" }}>
                  {e.name.charAt(0).toUpperCase()}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={styles.empName}>{e.name}</p>
                  <p style={styles.empMeta}>All-time: {e.count} sales</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={styles.empTotal}>₹{e.total.toFixed(2)}</p>
                  <p style={styles.empToday}>Today ₹{e.todayTotal.toFixed(2)}</p>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Products */}
      {tab === "products" && (
        <div style={styles.content} className="fade-up">
          <div style={styles.addProductForm}>
            <p style={styles.sectionLabel}>Add product</p>
            <input style={styles.input} placeholder="Product name" value={newName} onChange={e => setNewName(e.target.value)} />
            <input style={styles.input} placeholder="Price (₹)" type="number" value={newPrice} onChange={e => setNewPrice(e.target.value)} />
            <button style={styles.btnPrimary} onClick={handleAddProduct} disabled={adding}>
              {adding ? "Adding..." : "Add Product"}
            </button>
          </div>

          <p style={styles.sectionLabel} style={{ marginTop: "20px", fontSize: "12px", fontWeight: 700, color: "#64748B", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "10px" }}>All products</p>
          {products.length === 0 ? (
            <p style={styles.emptyMsg}>No products added yet.</p>
          ) : (
            <div style={styles.productList}>
              {products.map(p => {
                const stat = productStats[p.name];
                return (
                  <div key={p.id} style={styles.productRow}>
                    <div>
                      <p style={styles.productName}>{p.name}</p>
                      {stat && <p style={styles.productStat}>{stat.qty} units sold · ₹{stat.revenue.toFixed(2)}</p>}
                    </div>
                    <p style={styles.productPrice}>₹{p.price}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* All Sales */}
      {tab === "sales" && (
        <div style={styles.content} className="fade-up">
          <div style={styles.totalBanner}>
            <span>Total revenue</span>
            <span style={{ fontWeight: 700, color: "#10B981" }}>₹{totalAll.toFixed(2)}</span>
          </div>
          {sales.length === 0 ? (
            <p style={styles.emptyMsg}>No sales yet.</p>
          ) : (
            <div style={styles.salesList}>
              {sales.map(s => (
                <div key={s.id} style={styles.saleRow}>
                  <div style={{ ...styles.avatar, background: avatarColor(s.employeeName), width: "36px", height: "36px", fontSize: "14px", flexShrink: 0 }}>
                    {s.employeeName?.charAt(0).toUpperCase()}
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={styles.saleName}>{s.productName}</p>
                    <p style={styles.saleMeta}>{s.employeeName} · Qty {s.quantity} · {formatTime(s.createdAt)}</p>
                  </div>
                  <p style={styles.saleTotal}>₹{s.total?.toFixed(2)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const styles = {
  page: { minHeight: "100vh", background: "#0F172A", paddingBottom: "32px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 20px 0" },
  shopName: { fontSize: "20px", fontWeight: 800, color: "#F8FAFC" },
  sub: { fontSize: "13px", color: "#F59E0B", marginTop: "2px", fontWeight: 600 },
  headerRight: { display: "flex", alignItems: "center", gap: "8px" },
  codeBadge: { background: "rgba(245,158,11,0.15)", color: "#F59E0B", padding: "4px 10px", borderRadius: "20px", fontSize: "12px", fontWeight: 700, letterSpacing: "0.1em" },
  logoutBtn: { background: "rgba(255,255,255,0.06)", color: "#94A3B8", width: "32px", height: "32px", borderRadius: "8px", fontSize: "12px" },
  shareBanner: { margin: "16px 20px 0", background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: "14px", padding: "14px 16px", display: "flex", alignItems: "center", gap: "12px" },
  shareIcon: { fontSize: "20px" },
  shareTitle: { fontSize: "12px", color: "#94A3B8" },
  shareCode: { fontSize: "22px", fontWeight: 900, color: "#F59E0B", letterSpacing: "0.15em" },
  tabs: { display: "flex", margin: "16px 20px 0", background: "rgba(255,255,255,0.05)", borderRadius: "12px", padding: "4px", gap: "2px" },
  tab: { flex: 1, padding: "9px 4px", borderRadius: "10px", fontSize: "12px", fontWeight: 600, background: "transparent", color: "#64748B" },
  tabActive: { background: "#1E293B", color: "#F8FAFC" },
  content: { padding: "16px 20px" },
  sectionLabel: { fontSize: "12px", fontWeight: 700, color: "#64748B", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "10px" },
  statsGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "20px" },
  bigStatCard: { background: "linear-gradient(135deg, #F59E0B 0%, #D97706 100%)", borderRadius: "18px", padding: "20px", gridColumn: "1 / -1" },
  bigStatLabel: { fontSize: "12px", color: "rgba(255,255,255,0.75)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" },
  bigStatValue: { fontSize: "40px", fontWeight: 900, color: "#fff", letterSpacing: "-2px", lineHeight: 1.1, marginTop: "4px" },
  bigStatSub: { fontSize: "13px", color: "rgba(255,255,255,0.65)", marginTop: "6px" },
  smallStatsCol: { display: "contents" },
  smallStatCard: { background: "#1E293B", borderRadius: "14px", padding: "16px" },
  smallStatLabel: { fontSize: "12px", color: "#64748B", fontWeight: 600 },
  smallStatValue: { fontSize: "24px", fontWeight: 800, color: "#F8FAFC", marginTop: "4px" },
  leaderboard: { display: "flex", flexDirection: "column", gap: "8px" },
  leaderRow: { display: "flex", justifyContent: "space-between", alignItems: "center", background: "#1E293B", borderRadius: "14px", padding: "14px 16px" },
  leaderLeft: { display: "flex", alignItems: "center", gap: "12px" },
  avatar: { width: "40px", height: "40px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px", fontWeight: 800, color: "#fff", flexShrink: 0 },
  leaderName: { fontSize: "14px", fontWeight: 700, color: "#F8FAFC" },
  leaderMeta: { fontSize: "12px", color: "#64748B", marginTop: "2px" },
  leaderRight: { display: "flex", alignItems: "center", gap: "6px" },
  leaderTotal: { fontSize: "16px", fontWeight: 800, color: "#F8FAFC" },
  crown: { fontSize: "16px" },
  emptyMsg: { color: "#64748B", fontSize: "14px", textAlign: "center", padding: "32px 0" },
  employeeCard: { display: "flex", alignItems: "center", gap: "14px", background: "#1E293B", borderRadius: "14px", padding: "16px", marginBottom: "8px" },
  empName: { fontSize: "15px", fontWeight: 700, color: "#F8FAFC" },
  empMeta: { fontSize: "12px", color: "#64748B", marginTop: "2px" },
  empTotal: { fontSize: "16px", fontWeight: 800, color: "#F8FAFC" },
  empToday: { fontSize: "12px", color: "#F59E0B", fontWeight: 600, marginTop: "2px" },
  addProductForm: { background: "#1E293B", borderRadius: "16px", padding: "16px", marginBottom: "16px", display: "flex", flexDirection: "column", gap: "10px" },
  input: { width: "100%", padding: "12px 14px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "10px", color: "#F8FAFC", fontSize: "14px" },
  btnPrimary: { width: "100%", padding: "14px", background: "#F59E0B", color: "#fff", borderRadius: "10px", fontSize: "14px", fontWeight: 700 },
  productList: { display: "flex", flexDirection: "column", gap: "8px" },
  productRow: { display: "flex", justifyContent: "space-between", alignItems: "center", background: "#1E293B", borderRadius: "12px", padding: "14px 16px" },
  productName: { fontSize: "14px", fontWeight: 600, color: "#F8FAFC" },
  productStat: { fontSize: "12px", color: "#64748B", marginTop: "2px" },
  productPrice: { fontSize: "18px", fontWeight: 800, color: "#F59E0B" },
  totalBanner: { display: "flex", justifyContent: "space-between", background: "#1E293B", borderRadius: "12px", padding: "14px 16px", marginBottom: "12px", fontSize: "14px", color: "#94A3B8" },
  salesList: { display: "flex", flexDirection: "column", gap: "8px" },
  saleRow: { display: "flex", alignItems: "center", gap: "12px", background: "#1E293B", borderRadius: "12px", padding: "12px 14px" },
  saleName: { fontSize: "14px", fontWeight: 600, color: "#F8FAFC" },
  saleMeta: { fontSize: "12px", color: "#64748B", marginTop: "2px" },
  saleTotal: { fontSize: "15px", fontWeight: 800, color: "#10B981", flexShrink: 0 },
  emptyState: { textAlign: "center", padding: "48px 20px" },
  emptyIcon: { fontSize: "40px", marginBottom: "12px" },
  emptyText: { fontSize: "16px", fontWeight: 700, color: "#F8FAFC", marginBottom: "6px" },
  emptySub: { fontSize: "13px", color: "#64748B" },
};

export default ManagerDashboard;
