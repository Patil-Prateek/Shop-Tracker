import React, { useState } from "react";
import { createShop, getShop } from "../firebase/services";

const WelcomePage = ({ onJoin }) => {
  const [mode, setMode] = useState(null); // 'create' | 'join'
  const [shopName, setShopName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [shopCode, setShopCode] = useState("");
  const [employeeName, setEmployeeName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleCreate = async () => {
    if (!shopName.trim() || !ownerName.trim()) return setError("Fill in all fields.");
    setLoading(true); setError("");
    try {
      const code = await createShop(shopName.trim(), ownerName.trim());
      onJoin({ shopCode: code, name: ownerName.trim(), role: "manager" });
    } catch (e) {
      setError("Failed to create shop. Check connection.");
    }
    setLoading(false);
  };

  const handleJoin = async () => {
    if (!shopCode.trim() || !employeeName.trim()) return setError("Fill in all fields.");
    setLoading(true); setError("");
    try {
      const shop = await getShop(shopCode.trim());
      if (!shop) return setError("Shop not found. Check your code.");
      onJoin({ shopCode: shop.code, shopName: shop.name, name: employeeName.trim(), role: "employee" });
    } catch (e) {
      setError("Failed to join. Check connection.");
    }
    setLoading(false);
  };

  return (
    <div style={styles.page}>
      <div style={styles.container} className="fade-up">
        {/* Logo */}
        <div style={styles.logo}>
          <div style={styles.logoIcon}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <path d="M3 3h18v4H3zM3 9h18v12H3z" stroke="#10B981" strokeWidth="2" strokeLinejoin="round"/>
              <path d="M9 13h6M9 16h4" stroke="#10B981" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>
          <span style={styles.logoText}>ShopSync</span>
        </div>

        <h1 style={styles.headline}>Sales tracking,<br/>made simple.</h1>
        <p style={styles.sub}>Every employee logs sales on their device. Everything syncs instantly.</p>

        {!mode && (
          <div style={styles.btnGroup} className="fade-up-delay">
            <button style={styles.btnPrimary} onClick={() => setMode("create")}>
              Create a Shop
            </button>
            <button style={styles.btnSecondary} onClick={() => setMode("join")}>
              Join with Shop Code
            </button>
          </div>
        )}

        {mode === "create" && (
          <div style={styles.form} className="fade-up">
            <p style={styles.formTitle}>Set up your shop</p>
            <input
              style={styles.input}
              placeholder="Shop name (e.g. Raja Stores)"
              value={shopName}
              onChange={e => setShopName(e.target.value)}
            />
            <input
              style={styles.input}
              placeholder="Your name (owner)"
              value={ownerName}
              onChange={e => setOwnerName(e.target.value)}
            />
            {error && <p style={styles.error}>{error}</p>}
            <button style={styles.btnPrimary} onClick={handleCreate} disabled={loading}>
              {loading ? "Creating..." : "Create Shop →"}
            </button>
            <button style={styles.btnGhost} onClick={() => { setMode(null); setError(""); }}>
              Back
            </button>
          </div>
        )}

        {mode === "join" && (
          <div style={styles.form} className="fade-up">
            <p style={styles.formTitle}>Join your shop</p>
            <input
              style={{ ...styles.input, textTransform: "uppercase", letterSpacing: "0.15em", fontWeight: 700 }}
              placeholder="SHOP CODE"
              value={shopCode}
              onChange={e => setShopCode(e.target.value.toUpperCase())}
              maxLength={6}
            />
            <input
              style={styles.input}
              placeholder="Your name"
              value={employeeName}
              onChange={e => setEmployeeName(e.target.value)}
            />
            {error && <p style={styles.error}>{error}</p>}
            <button style={styles.btnPrimary} onClick={handleJoin} disabled={loading}>
              {loading ? "Joining..." : "Join Shop →"}
            </button>
            <button style={styles.btnGhost} onClick={() => { setMode(null); setError(""); }}>
              Back
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "24px",
    background: "linear-gradient(160deg, #0F172A 0%, #1E293B 100%)",
  },
  container: {
    width: "100%",
    maxWidth: "400px",
    display: "flex",
    flexDirection: "column",
    gap: "16px",
  },
  logo: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    marginBottom: "8px",
  },
  logoIcon: {
    width: "44px",
    height: "44px",
    background: "rgba(16,185,129,0.12)",
    borderRadius: "12px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    border: "1px solid rgba(16,185,129,0.25)",
  },
  logoText: {
    fontSize: "22px",
    fontWeight: 800,
    color: "#F8FAFC",
    letterSpacing: "-0.5px",
  },
  headline: {
    fontSize: "36px",
    fontWeight: 900,
    lineHeight: 1.1,
    letterSpacing: "-1px",
    color: "#F8FAFC",
  },
  sub: {
    fontSize: "15px",
    color: "#94A3B8",
    lineHeight: 1.6,
  },
  btnGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    marginTop: "8px",
  },
  btnPrimary: {
    width: "100%",
    padding: "16px",
    background: "#10B981",
    color: "#fff",
    borderRadius: "12px",
    fontSize: "15px",
    fontWeight: 700,
    transition: "opacity 0.2s",
  },
  btnSecondary: {
    width: "100%",
    padding: "16px",
    background: "rgba(248,250,252,0.08)",
    color: "#F8FAFC",
    borderRadius: "12px",
    fontSize: "15px",
    fontWeight: 600,
    border: "1px solid rgba(248,250,252,0.12)",
  },
  btnGhost: {
    width: "100%",
    padding: "12px",
    background: "transparent",
    color: "#64748B",
    borderRadius: "12px",
    fontSize: "14px",
    fontWeight: 500,
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    marginTop: "4px",
  },
  formTitle: {
    fontSize: "18px",
    fontWeight: 700,
    color: "#F8FAFC",
    marginBottom: "4px",
  },
  input: {
    width: "100%",
    padding: "14px 16px",
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: "12px",
    color: "#F8FAFC",
    fontSize: "15px",
  },
  error: {
    color: "#EF4444",
    fontSize: "13px",
    padding: "10px 12px",
    background: "rgba(239,68,68,0.1)",
    borderRadius: "8px",
  },
};

export default WelcomePage;
